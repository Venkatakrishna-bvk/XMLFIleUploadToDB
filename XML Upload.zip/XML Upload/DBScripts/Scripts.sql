drop table Departments

Create table Departments
(
     ID int primary key,
     Name nvarchar(50),
     Location nvarchar(50)
)
GO

TRUNCATE TABLE Departments
select * from Departments