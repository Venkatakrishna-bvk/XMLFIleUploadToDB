USE [BVK]
GO

/****** Object:  StoredProcedure [dbo].[UP_SaveDepartment]    Script Date: 7/16/2021 7:14:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[UP_SaveDepartment]  
@DepartmentType DepartmentType READONLY
AS
BEGIN
DECLARE @p_ErrorNumber varchar(50), @p_ErrorMessage varchar(max)
	
	 BEGIN TRY   
MERGE Departments AS Target
USING @DepartmentType AS Source
ON Target.ID = Source.ID
WHEN MATCHED THEN
     UPDATE SET Target.Name = Source.Name,
	            Target.Location=Source.Location
WHEN NOT MATCHED BY TARGET THEN
      INSERT ([ID], [Name],[Location])
 values(Source.ID,
 Source.Name,Source.Location);
 End TRY
	 BEGIN CATCH                
                        
                      SELECT @p_ErrorNumber= ERROR_NUMBER(),  @p_ErrorMessage=ERROR_MESSAGE();                
                                
                                   
       END CATCH; 
	   
	   END

GO


