USE [BVK]
GO

/****** Object:  UserDefinedTableType [dbo].[DepartmentType]    Script Date: 7/16/2021 7:19:47 PM ******/
Create TYPE [dbo].[DepartmentType] AS TABLE(
	[Id] nvarchar NOT NULL,
	[Name] [varchar](200) NULL,
	[Location] [varchar](100) NULL
)
GO


Drop type [dbo].[DepartmentType] 

DROP SP [dbo].[UP_SaveDepartment]   



