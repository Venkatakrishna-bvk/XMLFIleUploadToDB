﻿using System;
using System.Data;
using System.IO;
using TEST.Service;

namespace TEST
{

    public class Program
    {

        public static void Main(string[] args)
        {
            XMLService startup = new XMLService();
            startup.Run();
        }
    }



}
