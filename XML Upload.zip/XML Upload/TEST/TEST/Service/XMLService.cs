﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;

namespace TEST.Service
{
    public class XMLService
    {


        public static IConfiguration GetConfiguration()
        {
            var builder = new ConfigurationBuilder()
                               .AddJsonFile("appsettings.json")
                               .AddJsonFile($"appsettings.json");
            var Configuration = builder.Build();

            return Configuration;
        }
        public static string GetConnectionString()
        {
            IConfiguration _Configuration = GetConfiguration();
            var connectionString = _Configuration.GetConnectionString("CS");
            return connectionString;
        }

        public void Run()
        {
            Console.WriteLine("Hello World!");

           UploadXMLToDB();
           // UploadXMLToDBSP();


        }
        public DataSet ReadXML()
        {

            string filePath = Path.Combine(Directory.GetCurrentDirectory(), @"XML\Sample.xml");

            DataSet ds = new DataSet();
            ds.ReadXml(filePath, XmlReadMode.InferTypedSchema);
            return ds;
        }

        public void UploadXMLToDB()
        {
            try
            {
                string cs = GetConnectionString();
                DataSet ds = ReadXML();
                DataTable dtDept = ds.Tables["Department"];

                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();
                    using (SqlBulkCopy bc = new SqlBulkCopy(con))
                    {
                        bc.DestinationTableName = "Departments";
                        bc.ColumnMappings.Add("ID", "ID");
                        bc.ColumnMappings.Add("Name", "Name");
                        bc.ColumnMappings.Add("Location", "Location");
                        bc.WriteToServer(dtDept);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }


        }

        //public void UploadXMLToDBSP()
        //{
        //    try
        //    {
        //        string cs = GetConnectionString();
        //        DataSet ds = ReadXML();
        //        DataTable dtDept = ds.Tables["Department"];

        //        using (SqlConnection conn = new SqlConnection(cs))
        //        {
        //            conn.Open();
        //            using (SqlCommand cmd = new SqlCommand())
        //            {
        //                cmd.Connection = conn;
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.CommandText = "UP_SaveDepartment";
        //                SqlParameter paramTVP = new SqlParameter()
        //                {
        //                    ParameterName = "@DepartmentType",
        //                    Value = dtDept
        //                };
        //                cmd.Parameters.Add(paramTVP);

        //                cmd.ExecuteNonQuery();

        //            }

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.StackTrace);
        //    }


       // }

    }
}
